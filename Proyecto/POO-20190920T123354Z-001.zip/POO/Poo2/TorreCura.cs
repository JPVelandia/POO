﻿using System;

public class Class1
{
	class TorreCura
	{

	}
}
